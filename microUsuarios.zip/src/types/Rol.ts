export interface Rol {
  id: string;
  nombre: string;
  descripcion?: string;
}
